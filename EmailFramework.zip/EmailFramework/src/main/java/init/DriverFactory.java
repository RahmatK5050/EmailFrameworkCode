package init;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import constants.Constants;
import utils.FileOperations;

public class DriverFactory {
	 WebDriver driver;
	FileOperations fileOperations = new FileOperations();
	Constants constants = new Constants();
	static Map<String, RemoteWebDriver> map = new HashMap<String, RemoteWebDriver>();

	public WebDriver IntializeBrowser() throws Exception {

		String browser = fileOperations.getValueFromPropertyFile(constants.CONFIG_WEB_FILE_PATH, "BrowserName");
		switch (browser.toLowerCase()) {

		case "chrome":
			try {
			
				driver = new ChromeDriver();

			} catch (Exception e) {
				e.printStackTrace();
			}
			break;

		}
		return driver;
	}

}