package constants;

public class Constants {
	
	// we define fix things , which will be never changes
	public final String CONFIG_WEB_FILE_PATH = "src/main/java/config/AppConfig.properties";
	public final String CONFIG_LOG4J_FILE_PATH = "src/main/java/config/log4j.properties";
}
