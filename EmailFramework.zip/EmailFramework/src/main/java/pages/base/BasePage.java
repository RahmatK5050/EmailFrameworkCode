package pages.base;

import java.time.Duration;
import java.util.List;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BasePage {

	final int WAIT_FOR_SECONDS = 90;
	Logger log = null;

	public BasePage() {
		log = Logger.getLogger(BasePage.class);
	}

	/**
	 * @param driver
	 * @param elem
	 */
	public void waitForElementVisibility(WebDriver driver, WebElement elem) {
		WebDriverWait webDriverWait = new WebDriverWait(driver, Duration.ofSeconds(WAIT_FOR_SECONDS));
		webDriverWait.until(ExpectedConditions.visibilityOf(elem));
	}

	/**
	 * @param driver
	 * @param locator
	 */
	public void waitForElementVisibility(WebDriver driver, By locator) {
		WebDriverWait webDriverWait = new WebDriverWait(driver, Duration.ofSeconds(WAIT_FOR_SECONDS));
		webDriverWait.until(ExpectedConditions.presenceOfElementLocated(locator));
		webDriverWait.until(ExpectedConditions.visibilityOf(driver.findElement(locator)));
		webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(locator));
	}

	public void waitForElementVisibility3(WebDriver driver, By locator) {
		WebDriverWait webDriverWait = new WebDriverWait(driver, Duration.ofSeconds(WAIT_FOR_SECONDS));
		webDriverWait.until(ExpectedConditions.presenceOfElementLocated(locator));
		webDriverWait.until(ExpectedConditions.visibilityOf(driver.findElement(locator)));
		webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(locator));
	}

	public void waitForElementVisibility2(WebDriver driver, By locator) {
		WebDriverWait webDriverWait = new WebDriverWait(driver, Duration.ofSeconds(WAIT_FOR_SECONDS));
		webDriverWait.until(ExpectedConditions.presenceOfElementLocated(locator));
	}

	/**
	 * @param driver
	 * @param elem
	 */
	public void waitForElementInVisibility(WebDriver driver, WebElement elem) {
		WebDriverWait webDriverWait = new WebDriverWait(driver, Duration.ofSeconds(WAIT_FOR_SECONDS));
		webDriverWait.until(ExpectedConditions.invisibilityOf(elem));
	}

	/**
	 * @param driver
	 * @param locator
	 */
	public void waitForElementInVisibility(WebDriver driver, By locator) {
		WebDriverWait webDriverWait = new WebDriverWait(driver, Duration.ofSeconds(WAIT_FOR_SECONDS));
		webDriverWait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
	}

	/**
	 * @param driver
	 * @param locator
	 */
	public void waitForElementClickability(WebDriver driver, By locator) {
		WebDriverWait webDriverWait = new WebDriverWait(driver, Duration.ofSeconds(WAIT_FOR_SECONDS));
		webDriverWait.until(ExpectedConditions.presenceOfElementLocated(locator));
		webDriverWait.until(ExpectedConditions.elementToBeClickable(locator));
	}

	/**
	 * @param driver
	 * @param locator
	 */
	public void waitForElementClickability(WebDriver driver, WebElement locator) {
		WebDriverWait webDriverWait = new WebDriverWait(driver, Duration.ofSeconds(WAIT_FOR_SECONDS));
		webDriverWait.until(ExpectedConditions.elementToBeClickable(locator));
	}

	/**
	 * @param driver
	 * @param locator
	 */
	public void waitForAllElementPresenceByElement(WebDriver driver, By locator) {
		WebDriverWait webDriverWait = new WebDriverWait(driver, Duration.ofSeconds(WAIT_FOR_SECONDS));
		webDriverWait.until(ExpectedConditions.presenceOfElementLocated(locator));
	}

	/**
	 * @param driver
	 * @param locator
	 */
	public void waitForvisibilityOfAllElements(WebDriver driver, List<WebElement> element) {
		WebDriverWait webDriverWait = new WebDriverWait(driver, Duration.ofSeconds(WAIT_FOR_SECONDS));
		webDriverWait.until(ExpectedConditions.visibilityOfAllElements(element));
	}

	/**
	 * @param driver
	 * @param locator
	 * @throws InterruptedException
	 */
	public void enterData(WebDriver driver, By locator, String value) {
		waitForElementClickability(driver, locator);
		hardWait(1000);
		driver.findElement(locator).click();
		hardWait(1000);
		driver.findElement(locator).clear();
		hardWait(2000);
		driver.findElement(locator).sendKeys(value);
	}

	public void uploadFile(WebDriver driver, By locator, String value) {
		driver.findElement(locator).sendKeys(value);
	}

	public void enterData(WebDriver driver, WebElement element, String value) {
		waitForElementClickability(driver, element);
		hardWait(1000);
		element.click();
		hardWait(1000);
		element.clear();
		hardWait(2000);
		element.sendKeys(value);
	}

	public void enterDataAndPressEnter(WebDriver driver, By locator, String value) {
		waitForElementClickability(driver, locator);
		hardWait(2000);
		driver.findElement(locator).clear();
		driver.findElement(locator).sendKeys(value);
		hardWait(2000);
		driver.findElement(locator).sendKeys(Keys.ENTER);
	}

	/**
	 * @param driver
	 * @param locator
	 * @param value
	 * @throws InterruptedException
	 */
	public void enterDataWithoutClearTextField(WebDriver driver, By locator, String value) {
		hardWait(1000);
		waitForElementVisibility(driver, locator);
		driver.findElement(locator).sendKeys(value);

	}

	public void enterDataInTextField(WebDriver driver, By locator, String value) {
		hardWait(3000);
		driver.findElement(locator).sendKeys(value);
	}

	/*
	 * @param driver
	 * 
	 * @param locator
	 * 
	 * @throws InterruptedException
	 */
	public void click(WebDriver driver, By locator) {
		try {
			hardWait(2000);
			waitForElementVisibility(driver, locator);
			waitForElementClickability(driver, locator);
			driver.findElement(locator).click();
			log.info("Click action performed successfully on element " + driver);
		} catch (TimeoutException e) {
			hardWait(2000);
			driver.findElement(locator).click();
		} catch (NoSuchElementException e) {
			hardWait(2000);
			JSClick(driver, driver.findElement(locator));
		}
	}

	public void clear(WebDriver driver, By locator) {
		try {
			hardWait(2000);
			waitForElementVisibility(driver, locator);
			waitForElementClickability(driver, locator);
			driver.findElement(locator).clear();
			log.info("clear action performed successfully on element " + driver);
		} catch (TimeoutException e) {
			hardWait(2000);
			driver.findElement(locator).click();
		} catch (NoSuchElementException e) {
			hardWait(2000);
			JSClick(driver, driver.findElement(locator));
		}
	}

	public void JSClick(WebDriver driver, WebElement element) {
		JavascriptExecutor jse2 = (JavascriptExecutor) driver;
		jse2.executeScript("arguments[0].click();", element);
	}

	public void JSClickByLocator(WebDriver driver, By locator) {
		JavascriptExecutor jse2 = (JavascriptExecutor) driver;
		jse2.executeScript("arguments[0].click();", locator);
	}

	/**
	 * @param driver
	 * @param locator
	 * @param text
	 */
	public void dropdownSelectByText(WebDriver driver, By locator, String text) {
		try {
			waitForElementVisibility(driver, locator);
			Select dropdown = new Select(driver.findElement(locator));
			dropdown.selectByVisibleText(text);
			log.info("SelectByVisibleText action performed successfully on element " + driver);
		} catch (TimeoutException e) {
			log.error("Timeout occurs while selecting dropdrown option for element " + locator);
			e.printStackTrace();
		} catch (NoSuchElementException e) {
			log.error("NoSuchElementException occurs while selecting dropdrown option " + locator);
		}
	}

	/**
	 * @param driver
	 * @param locator
	 * @param text
	 */
	public void dropdownSelectByText(WebDriver driver, WebElement element, String text) {
		hardWait(3000);
		try {
			Select dropdown = new Select(element);
			dropdown.selectByVisibleText(text);
			log.info("SelectByVisibleText action performed successfully on element " + driver);
		} catch (TimeoutException e) {
			log.error("Timeout occurs while selecting dropdrown option for element " + element);
			e.printStackTrace();
		} catch (NoSuchElementException e) {
			log.error("NoSuchElementException occurs while selecting dropdrown option " + element);
		}
	}

	/**
	 * @param driver
	 * @param locator
	 * @param index
	 */
	public void dropdownSelectByIndex(WebDriver driver, By locator, int index) {
		try {
			waitForElementVisibility(driver, locator);
			Select dropdown = new Select(driver.findElement(locator));
			dropdown.selectByIndex(index);
			log.info("SelectByIndex action performed successfully on element " + driver);
		} catch (TimeoutException e) {
			log.error("Timeout occurs while selecting dropdrown option for element " + locator);
			e.printStackTrace();
		} catch (NoSuchElementException e) {
			log.error("NoSuchElementException occurs while selecting dropdrown option " + locator);
		}
	}

	public void pageRefresh(WebDriver driver) {
		driver.navigate().refresh();
		hardWait(3000);
	}

	/**
	 * @param driver
	 * @param locator
	 * @param value
	 */
	public void dropdownSelectByValue(WebDriver driver, By locator, String value) {
		try {
			waitForElementVisibility(driver, locator);
			Select dropdown = new Select(driver.findElement(locator));
			dropdown.selectByValue(value);
			log.info("SelectByValue action performed successfully on element " + driver);
		} catch (TimeoutException e) {
			log.error("Timeout occurs while selecting dropdrown option for element " + locator);
			e.printStackTrace();
		} catch (NoSuchElementException e) {
			log.error("NoSuchElementException occurs while selecting dropdrown option " + locator);
		}
	}

	/**
	 * @param driver
	 * @param locators
	 * @return
	 * @throws InterruptedException
	 */
	public boolean isElementEnabled(WebDriver driver, WebElement element) {
		boolean status;
		try {
			status = element.isEnabled();
		} catch (Exception e) {
			status = false;
		}
		return status;
	}

	public boolean isElementEnabled(WebDriver driver, By locators) {
		boolean status;
		try {
			status = driver.findElement(locators).isEnabled();
		} catch (Exception e) {
			status = false;
		}
		return status;
	}

	public boolean isElementPresent(WebDriver driver, By locators) {
		boolean status;
		try {
			status = driver.findElement(locators).isDisplayed();
		} catch (Exception e) {
			status = false;
		}
		return status;
	}

	public boolean isElementPresent(WebDriver driver, WebElement element) {
		boolean status;
		try {
			status = element.isDisplayed();
		} catch (NoSuchElementException e) {
			status = false;
		}
		return status;
	}

	public boolean checkIfElementIsSelected(WebDriver driver, By locator) {
		try {
			WebDriverWait webDriverWait = new WebDriverWait(driver, Duration.ofSeconds(3));
			webDriverWait.until(ExpectedConditions.elementToBeSelected(locator));
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public boolean isElementSelected(WebDriver driver, WebElement element) {
		boolean status;
		if (element.isSelected()) {
			status = true;
		} else {
			status = false;
		}
		return status;
	}

	public boolean isLocatorSelected(WebDriver driver, By locator) {
		boolean status;
		if (driver.findElement(locator).isSelected()) {
			status = true;
		} else {
			status = false;
		}
		return status;
	}

	public boolean checkIfElementIsClickable(WebDriver driver, By locator) {
		try {
			WebDriverWait webDriverWait = new WebDriverWait(driver, Duration.ofSeconds(10));
			webDriverWait.until(ExpectedConditions.elementToBeClickable(locator));
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public boolean checkIfElementIsClickable(WebDriver driver, By locator, int waitTimeForSeconds) {
		try {
			WebDriverWait webDriverWait = new WebDriverWait(driver, Duration.ofSeconds(WAIT_FOR_SECONDS));
			webDriverWait.until(ExpectedConditions.elementToBeClickable(locator));
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public boolean checkIfElementIsClickable(WebDriver driver, WebElement element) {
		try {
			WebDriverWait webDriverWait = new WebDriverWait(driver, Duration.ofSeconds(WAIT_FOR_SECONDS));
			webDriverWait.until(ExpectedConditions.elementToBeClickable(element));
			return true;
		} catch (Exception e) {
			return false;

		}
	}

	public boolean checkIfElementIsClickable(WebDriver driver, WebElement element, int waitTimeForSeconds) {
		try {
			WebDriverWait webDriverWait = new WebDriverWait(driver, Duration.ofSeconds(WAIT_FOR_SECONDS));
			webDriverWait.until(ExpectedConditions.elementToBeClickable(element));
			return true;
		} catch (Exception e) {
			return false;

		}
	}

	public String getText(WebDriver driver, By locator) {
		waitForElementVisibility(driver, locator);
		try {
			return driver.findElement(locator).getText().trim();
		} catch (StaleElementReferenceException e) {
			return driver.findElement(locator).getText().trim();
		}
	}

	public String getText(WebDriver driver, WebElement locator) {
		waitForElementVisibility(driver, locator);
		try {
			return locator.getText().trim();
		} catch (StaleElementReferenceException e) {
			return locator.getText().trim();
		}
	}

	/**
	 * @param driver
	 * @param element
	 */
	public void mouseHover(WebDriver driver, WebElement element) {
		Actions action = new Actions(driver);
		action.moveToElement(element).build().perform();
	}

	public void hardWait(int milliSeconds) {
		try {
			Thread.sleep(milliSeconds);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void backToNavigate(WebDriver driver) {
		driver.navigate().back();
	}

}