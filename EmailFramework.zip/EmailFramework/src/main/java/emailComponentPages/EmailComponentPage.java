package emailComponentPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import constants.Constants;
import pages.base.BasePage;
import utils.FileOperations;

public class EmailComponentPage extends BasePage {
	Constants constants = new Constants();
	FileOperations fileOperations = new FileOperations();
	String browser = fileOperations.getValueFromPropertyFile(constants.CONFIG_WEB_FILE_PATH, "url");
	String EmailOrPhone = fileOperations.getValueFromPropertyFile(constants.CONFIG_WEB_FILE_PATH, "EmailOrPhone");
	String Password = fileOperations.getValueFromPropertyFile(constants.CONFIG_WEB_FILE_PATH, "Password");

	String RecipientEmail = fileOperations.getValueFromPropertyFile(constants.CONFIG_WEB_FILE_PATH, "RecipientEmail");
	String EmailSubject = fileOperations.getValueFromPropertyFile(constants.CONFIG_WEB_FILE_PATH, "EmailSubject");
	String EmailBody = fileOperations.getValueFromPropertyFile(constants.CONFIG_WEB_FILE_PATH, "EmailBody");

	String FileToAttach = "D:\\EclipseWorkplace\\EmailFramework\\testData\\ComPoseEmailCases.xlsx";

	By EmailOrPhoneTextField = By.xpath("//input[@id='identifierId']");
	By NextButton = By.xpath("//span[normalize-space()='Next']");
	By PasswordTextField = By.xpath("//input[@name='Passwd']");
	By NotButton = By.xpath("//span[normalize-space()='Not now']");
	By ComposeButton = By.xpath("//div[contains(text(),'Compose')]");
	By RecipeientPath = By.xpath("//input[@class='agP aFw']");
	By subject = By.xpath("//input[@class='aoT']");
	By MailBody = By.xpath("//div[@class='Am aiL Al editable LW-avf tS-tW']");
	By SendButton = By.xpath("//div[text()='Send']");
	By MessagePopup = By.xpath("//span[contains(text(),'Message sent')]");
	By AttachButton = By.xpath("//div[@class='a1 aaA aMZ']");

	public void LoginEmail(WebDriver driver) {
		hardWait(3000);
		enterData(driver, EmailOrPhoneTextField, EmailOrPhone);
		click(driver, NextButton);
		hardWait(2000);
		enterData(driver, PasswordTextField, Password);
		if (isElementPresent(driver, NotButton) == true) {
			click(driver, NotButton);
			hardWait(2000);
		}
	}

	public boolean CheckComposeButtonPrsent(WebDriver driver) {
		if (isElementPresent(driver, ComposeButton) == true) {
			return true;
		} else {
			return false;
		}
	}

	public boolean CheckComposeButtonClickable(WebDriver driver) {
		if (checkIfElementIsClickable(driver, ComposeButton) == true) {
			return true;
		} else {
			return false;
		}
	}

	public void clickonComposeButton(WebDriver driver) {
		click(driver, ComposeButton);
		hardWait(2000);
	}

	public void EnterRecipientSubjectAndMessage(WebDriver driver) {
		enterData(driver, RecipeientPath, RecipientEmail);
		hardWait(1000);
		enterData(driver, subject, EmailSubject);
		hardWait(1000);
		enterData(driver, MailBody, EmailBody);
		hardWait(1000);
	}

	public void ClickOnSendButton(WebDriver driver) {
		click(driver, SendButton);
	}

	public String VerifySentMsg(WebDriver driver) {
		return getText(driver, MessagePopup);
	}

	public void AttachFile(WebDriver driver) {
		uploadFile(driver, AttachButton, FileToAttach);
		hardWait(2000);
	}

	By AttachmentBox = By.xpath("//div[@id=':18j']");

	public boolean CheckAttachmentBoxPrsent(WebDriver driver) {
		if (isElementPresent(driver, AttachmentBox) == true) {
			return true;
		} else {
			return false;
		}
	}

	public void EnterMultipleRecipeientEmail(WebDriver driver) {
		enterDataAndPressEnter(driver, RecipeientPath, "test@gmail.com");
		hardWait(1000);
		enterDataAndPressEnter(driver, RecipeientPath, "test1@gmail.com");
		hardWait(1000);
		enterDataAndPressEnter(driver, RecipeientPath, "test2@gmail.com");
		hardWait(1000);
	}

	By MultipleRecipeientEmailBox = By.xpath("(//div[@class='afx'])[1]");
	public boolean CheckMultipleRecipeientEmailBoxPrsent(WebDriver driver) {
		if (isElementPresent(driver, MultipleRecipeientEmailBox) == true) {
			return true;
		} else {
			return false;
		}
	}
	
	
	By saveAnddraftButton = By.xpath("//img[@class='Ha']");
	public void clickonsaveAnddraftButton(WebDriver driver) {
		click(driver, saveAnddraftButton);
		hardWait(2000);
	}
	
	By DraftButton = By.xpath("//a[contains(text(),'Drafts')]");
	By DraftButtonBox = By.xpath("(//span[contains(text(),'Draft')])[2]");
	public Boolean VerifyEmailInDrafts(WebDriver driver)
	{
		click(driver, DraftButton);
		hardWait(2000);
		if (isElementPresent(driver, DraftButtonBox) == true) {
			return true;
		} else {
			return false;
		}
	}
	
	public void ClickOnDraftButton(WebDriver driver)
	{
		click(driver, DraftButton);
		hardWait(2000);
	}
	
	
	By SelectButton = By.xpath("//span[contains(@class,'T-Jo J-J5-Ji T-Jo-auq T-Jo-iAfbIe')]");
	By DiscardDraftsButton = By.xpath("//div[@class='Bn']");
	public void ClickOnDiscardDraftButton(WebDriver driver)
	{
		click(driver, SelectButton);
		hardWait(2000);
		click(driver, DiscardDraftsButton);
		hardWait(2000);
	}
}
