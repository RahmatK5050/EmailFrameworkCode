package runner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src\\test\\resources\\EmailComposeFeatures\\EmailCompose2.feature",

		glue = { "emailComposeSteps2" },

		plugin = { "pretty", "json:target/jsonReports/Cucumber.json",
				"html:Extent Reports/Cucumber.html" }, monochrome = true)
public class TestRunner {

}
