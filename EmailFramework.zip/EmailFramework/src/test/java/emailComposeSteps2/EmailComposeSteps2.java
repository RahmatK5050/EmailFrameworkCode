package emailComposeSteps2;

import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;

import constants.Constants;

import org.apache.commons.mail.Email;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import utils.FileOperations;

public class EmailComposeSteps2 {
	Constants constants = new Constants();
	FileOperations fileOperations = new FileOperations();
	String EmailOrPhone = fileOperations.getValueFromPropertyFile(constants.CONFIG_WEB_FILE_PATH, "EmailOrPhone");
	String Password = fileOperations.getValueFromPropertyFile(constants.CONFIG_WEB_FILE_PATH, "Password");

	String RecipientEmail = fileOperations.getValueFromPropertyFile(constants.CONFIG_WEB_FILE_PATH, "RecipientEmail");
	String EmailSubject = fileOperations.getValueFromPropertyFile(constants.CONFIG_WEB_FILE_PATH, "EmailSubject");
	String EmailBody = fileOperations.getValueFromPropertyFile(constants.CONFIG_WEB_FILE_PATH, "EmailBody");
	private Email email;

	@Given("User is on the email sending page")
	public void user_is_on_the_email_sending_page() {

	}

	@When("User fills in the email details")
	public void user_fills_in_the_email_details() {

		email = new HtmlEmail();
		email.setHostName("smtp.gmail.com");
		email.setSmtpPort(587);
		email.setAuthenticator(new DefaultAuthenticator(EmailOrPhone, Password));
		email.setStartTLSEnabled(true);

		try {
			// Set email details
			email.setFrom(EmailOrPhone, "Test1");
			email.addTo(RecipientEmail, "Test2");
			email.setSubject(EmailSubject);
			email.setMsg(EmailBody);
		} catch (EmailException e) {
			System.err.println("Email setting failed: " + e.getMessage());
		}
	}

	@When("User clicks on the send button")
	public void user_clicks_on_the_send_button() {
		try {
			// Send the email
			email.send();
			System.out.println("Email sent successfully");
		} catch (EmailException e) {
			System.err.println("Email sending failed: " + e.getMessage());
		}
	}

	@Then("Email should be sent successfully")
	public void email_should_be_sent_successfully() {

	}

}
