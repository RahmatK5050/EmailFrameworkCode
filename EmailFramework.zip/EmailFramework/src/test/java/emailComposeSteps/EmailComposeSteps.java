package emailComposeSteps;

import org.openqa.selenium.WebDriver;
import org.testng.asserts.SoftAssert;

import constants.Constants;
import emailComponentPages.EmailComponentPage;
import init.DriverFactory;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import utils.FileOperations;

public class EmailComposeSteps {

	SoftAssert softassert = new SoftAssert();
	EmailComponentPage obj = new EmailComponentPage();
	FileOperations fileOperations = new FileOperations();
	DriverFactory DriverFactoryobj = new DriverFactory();
	Constants constants = new Constants();

	WebDriver driver;

	@Before
	public void lunch() throws Exception {
		String url = fileOperations.getValueFromPropertyFile(constants.CONFIG_WEB_FILE_PATH, "Url");
		driver = DriverFactoryobj.IntializeBrowser();
		driver.get(url);
		driver.manage().window().maximize();
	}

	@Given("User is on the Gmail login page")
	public void user_is_on_the_gmail_login_page() {
		System.out.println("user is on login page:");
	}

	@When("User enters valid credentials and logs in")
	public void user_enters_valid_credentials_and_logs_in() {
		obj.LoginEmail(driver);
	}

	@Then("User should see the Compose button")
	public void user_should_see_the_compose_button() {
		Boolean value = obj.CheckComposeButtonPrsent(driver);
		softassert.assertEquals(value, true);
	}

	@Then("User should be able to click on the Compose button")
	public void user_should_be_able_to_click_on_the_compose_button() {
		Boolean value = obj.CheckComposeButtonClickable(driver);
		softassert.assertEquals(value, true);
	}

	@Given("User is on the Gmail inbox page")
	public void user_is_on_the_gmail_inbox_page() {
		System.out.println("User is on the Gmail inbox page");
	}

	@When("User clicks on the Compose button")
	public void user_clicks_on_the_compose_button() {
		obj.clickonComposeButton(driver);
	}

	@When("User fills in the recipient, subject, and message body")
	public void user_fills_in_the_recipient_subject_and_message_body() {
		obj.EnterRecipientSubjectAndMessage(driver);
	}

	@When("User clicks on the Send button")
	public void user_clicks_on_the_send_button() {
		obj.ClickOnSendButton(driver);
	}

	@Then("Email should be sent successfully")
	public void email_should_be_sent_successfully() {
		String Msg = obj.VerifySentMsg(driver);
		softassert.assertEquals(Msg, "Message sent");
	}

	@Given("User is composing a new email")
	public void user_is_composing_a_new_email() {
		obj.clickonComposeButton(driver);
	}

	@When("User clicks on the Attach files button")
	public void user_clicks_on_the_attach_files_button() {
		System.out.println("user is attaching file");
	}

	@When("User selects a file to attach")
	public void user_selects_a_file_to_attach() {
		obj.AttachFile(driver);
	}

	@Then("File should be attached successfully to the email")
	public void file_should_be_attached_successfully_to_the_email() {
		Boolean value = obj.CheckAttachmentBoxPrsent(driver);
		softassert.assertEquals(value, true);
	}

	@When("User enters multiple email addresses in the To field")
	public void user_enters_multiple_email_addresses_in_the_to_field() {
		obj.EnterMultipleRecipeientEmail(driver);
	}

	@Then("Multiple recipients should be added successfully")
	public void multiple_recipients_should_be_added_successfully() {
		Boolean value = obj.CheckMultipleRecipeientEmailBoxPrsent(driver);
		softassert.assertEquals(value, true);
	}

	@When("User fills in the email fields but does not send it")
	public void user_fills_in_the_email_fields_but_does_not_send_it() {
		obj.EnterMultipleRecipeientEmail(driver);
	}

	@When("User clicks on the Save draft button")
	public void user_clicks_on_the_save_draft_button() {
		obj.clickonsaveAnddraftButton(driver);
	}

	@Then("Email should be saved in the Drafts folder")
	public void email_should_be_saved_in_the_drafts_folder() {
		Boolean value = obj.VerifyEmailInDrafts(driver);
		softassert.assertEquals(value, true);
	}

	@Given("User has a drafted email in the Drafts folder")
	public void user_has_a_drafted_email_in_the_drafts_folder() {
		System.out.println("User is On Draft Folder");
	}

	@When("User opens the drafted email")
	public void user_opens_the_drafted_email() {
		obj.ClickOnDraftButton(driver);
	}

	@When("User clicks on the Discard draft button")
	public void user_clicks_on_the_discard_draft_button() {
		obj.ClickOnDiscardDraftButton(driver);
	}

	@Then("Email should be discarded successfully")
	public void email_should_be_discarded_successfully() {
		Boolean value = obj.VerifyEmailInDrafts(driver);
		softassert.assertEquals(value, false);
	}

}
